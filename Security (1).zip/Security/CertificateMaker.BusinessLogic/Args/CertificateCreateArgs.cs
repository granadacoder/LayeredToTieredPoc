﻿//-----------------------------------------------------------------------
// <copyright file="CertificateCreateArgs.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using System.Security;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Args
{
    public class CertificateCreateArgs
    {
        public const string CertificateMassageName = "CN={0}";

        public CertificateCreateArgs()
        {
            this.SubjectAlternateNames = new List<string>();
            this.AddCertificateAuthorityCertificateToStore = false;
            this.AddSelfSignedCertificateToStore = false;
        }

        public string SelfSignedCertificateSubjectName { get; set; }

        public string MassagedSelfSignedCertificateSubjectName
        {
            get
            {
                return string.Format(CertificateMassageName, SelfSignedCertificateSubjectName);
            }
        }

        public ICollection<string> SubjectAlternateNames { get; set; }

        public string CertificateFileName { get; set; }

        public string CertificateAuthoritySubjectName { get; set; }

        public string MassagedCertificateAuthoritySubjectName
        {
            get
            {
                return string.Format(CertificateMassageName, CertificateAuthoritySubjectName);
            }
        }

        public SecureString CertificateAuthorityPrivateKeyFilePasswordSecureString { get; set; }

        public SecureString SelfSignedCertificatePrivateKeyFilePasswordSecureString { get; set; }

        public string RootSigningCertificateFileName { get; set; }

        public int CertificateAddYears { get; set; }

        public bool AddCertificateAuthorityCertificateToStore { get; set; }

        public bool AddSelfSignedCertificateToStore { get; set; }
    }
}
