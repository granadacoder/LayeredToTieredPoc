﻿//-----------------------------------------------------------------------
// <copyright file="ICertificateReporter.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Security.Cryptography.X509Certificates;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Interfaces
{
    public interface ICertificateReporter
    {
        string GenerateShowCertificateAndChainReport(X509Certificate2 cert);
    }
}
