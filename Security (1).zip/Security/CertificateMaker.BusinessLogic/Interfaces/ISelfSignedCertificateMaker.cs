﻿//-----------------------------------------------------------------------
// <copyright file="ISelfSignedCertificateMaker.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Args;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Interfaces
{
    public interface ISelfSignedCertificateMaker
    {
        void CreateSelfSignedCertificate(CertificateCreateArgs args);
    }
}
