﻿//-----------------------------------------------------------------------
// <copyright file="IAdministratorChecker.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Utilities.Interfaces
{
    public interface IAdministratorChecker
    {
        bool IsAdministrator();
    }
}
