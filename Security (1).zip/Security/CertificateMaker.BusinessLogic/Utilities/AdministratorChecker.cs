﻿//-----------------------------------------------------------------------
// <copyright file="AdministratorChecker.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Security.Principal;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Utilities.Interfaces;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Utilities
{
    public class AdministratorChecker : IAdministratorChecker
    {
        public bool IsAdministrator()
        {
            var identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }
}
