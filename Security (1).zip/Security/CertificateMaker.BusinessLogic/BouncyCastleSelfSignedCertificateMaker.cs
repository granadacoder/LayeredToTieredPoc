﻿//-----------------------------------------------------------------------
// <copyright file="BouncyCastleSelfSignedCertificateMaker.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Args;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Interfaces;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Utilities.Interfaces;

using log4net;

using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Pkcs;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Prng;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.X509;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic
{
    public class BouncyCastleSelfSignedCertificateMaker : ISelfSignedCertificateMaker
    {
        public const string SignatureAlgorithm = "SHA256WithRSA";

        public const int KeyGenerationParametersKeyStrengthDefault = 2048;

        public const int Asn1SequenceCountNine = 9;

        public const string PfxExtension = ".pfx";

        public const string CerExtension = ".cer";

        private readonly ILog Logger;

        public BouncyCastleSelfSignedCertificateMaker(ILog lgr, ICertificateReporter icr, IAdministratorChecker adminChecker)
        {
            this.Logger = lgr;
            this.CertificateReporter = icr;
            this.AdministratorChecker = adminChecker;
        }

        private ICertificateReporter CertificateReporter { get; set; }

        private IAdministratorChecker AdministratorChecker { get; set; }

        public void CreateSelfSignedCertificate(CertificateCreateArgs args)
        {
            this.VerifyCertificateCreateArgs(args);
            args = this.MassageArgs(args);

            System.Security.Cryptography.X509Certificates.X509Certificate2 x509Cert;

            AsymmetricKeyParameter caPrivKey = GenerateCertificateAuthorityCertificate(args, outX509Cert: out x509Cert);
            string caReport = this.CertificateReporter.GenerateShowCertificateAndChainReport(x509Cert);
            System.Security.Cryptography.X509Certificates.X509Certificate2 cert = GenerateSelfSignedCertificate(args, caPrivKey);

            if (args.AddSelfSignedCertificateToStore)
            {
                this.AddCertToStore(cert, System.Security.Cryptography.X509Certificates.StoreName.My, System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine);
            }

            string selfSignReport = this.CertificateReporter.GenerateShowCertificateAndChainReport(cert);

            string reportFileName = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(args.CertificateFileName), "CertificateReport.txt");
            System.IO.File.WriteAllText(reportFileName, selfSignReport + System.Environment.NewLine + "####################################################################" + System.Environment.NewLine + caReport);
        }

        public System.Security.Cryptography.X509Certificates.X509Certificate2 GenerateSelfSignedCertificate(CertificateCreateArgs args, AsymmetricKeyParameter issuerPrivKey)
        {
            return GenerateSelfSignedCertificate(args, issuerPrivKey, KeyGenerationParametersKeyStrengthDefault);
        }

        public System.Security.Cryptography.X509Certificates.X509Certificate2 GenerateSelfSignedCertificate(CertificateCreateArgs args, AsymmetricKeyParameter issuerPrivKey, int keyStrength)
        {
            //// Generating Random Numbers
            CryptoApiRandomGenerator randomGenerator = new CryptoApiRandomGenerator();
            SecureRandom random = new SecureRandom(randomGenerator);

            //// The Certificate Generator
            X509V3CertificateGenerator certificateGenerator = new X509V3CertificateGenerator();

            //// Serial Number
            BigInteger serialNumber = BigIntegers.CreateRandomInRange(BigInteger.One, BigInteger.ValueOf(long.MaxValue), random);
            certificateGenerator.SetSerialNumber(serialNumber);

            //// Signature Algorithm
            certificateGenerator.SetSignatureAlgorithm(SignatureAlgorithm);

            //// Issuer and Subject Name
            X509Name subjectDN = new X509Name(args.MassagedSelfSignedCertificateSubjectName);
            X509Name issuerDN = new X509Name(args.MassagedCertificateAuthoritySubjectName);
            certificateGenerator.SetSubjectDN(subjectDN);
            /* here is the self signed part below */
            certificateGenerator.SetIssuerDN(issuerDN);

            //// Valid For
            DateTime notBefore = DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0));
            DateTime notAfter = notBefore.AddYears(args.CertificateAddYears);
            certificateGenerator.SetNotBefore(notBefore);
            certificateGenerator.SetNotAfter(notAfter);

            KeyUsage keyUsage = new KeyUsage(KeyUsage.DigitalSignature | KeyUsage.KeyEncipherment);
            certificateGenerator.AddExtension(X509Extensions.KeyUsage, true, keyUsage);

            //// Add the "Extended Key Usage" attribute, specifying "server authentication".
            KeyPurposeID[] usages = new[] { KeyPurposeID.IdKPServerAuth };
            certificateGenerator.AddExtension(
                X509Extensions.ExtendedKeyUsage.Id,
                false,
                new ExtendedKeyUsage(usages));

            if (args.SubjectAlternateNames.Count <= 1)
            {
                /* the <=1 is for the simple reason of showing an alternate syntax .. */
                foreach (string subjectAlternateName in args.SubjectAlternateNames)
                {
                    GeneralName altName = new GeneralName(GeneralName.DnsName, subjectAlternateName);
                    GeneralNames subjectAltName = new GeneralNames(altName);
                    certificateGenerator.AddExtension(X509Extensions.SubjectAlternativeName, false, subjectAltName);
                }
            }
            else
            {
                List<Asn1Encodable> asn1EncodableList = new List<Asn1Encodable>();
                foreach (string subjectAlternateName in args.SubjectAlternateNames)
                {
                    asn1EncodableList.Add(new GeneralName(GeneralName.DnsName, subjectAlternateName));
                }

                DerSequence subjectAlternativeNamesExtension = new DerSequence(asn1EncodableList.ToArray());
                certificateGenerator.AddExtension(X509Extensions.SubjectAlternativeName.Id, false, subjectAlternativeNamesExtension);
            }

            //// Subject Public Key
            AsymmetricCipherKeyPair subjectKeyPair;
            KeyGenerationParameters keyGenerationParameters = new KeyGenerationParameters(random, keyStrength);
            RsaKeyPairGenerator keyPairGenerator = new RsaKeyPairGenerator();
            keyPairGenerator.Init(keyGenerationParameters);
            subjectKeyPair = keyPairGenerator.GenerateKeyPair();

            certificateGenerator.SetPublicKey(subjectKeyPair.Public);

            //// Generating the Certificate
            AsymmetricCipherKeyPair issuerKeyPair = subjectKeyPair;

            //// selfsign certificate
            X509Certificate certificate = certificateGenerator.Generate(issuerPrivKey, random);

            //// correcponding private key
            PrivateKeyInfo pinfo = PrivateKeyInfoFactory.CreatePrivateKeyInfo(subjectKeyPair.Private);

            //// merge into X509Certificate2
            System.Security.Cryptography.X509Certificates.X509Certificate2 x509 = new System.Security.Cryptography.X509Certificates.X509Certificate2(certificate.GetEncoded());

            Asn1Sequence seq = (Asn1Sequence)Asn1Object.FromByteArray(pinfo.PrivateKey.GetDerEncoded());
            if (seq.Count != Asn1SequenceCountNine)
            {
                throw new PemException("malformed sequence in RSA private key");
            }

            RsaPrivateKeyStructure rsa = new RsaPrivateKeyStructure(seq);
            RsaPrivateCrtKeyParameters rsaparams = new RsaPrivateCrtKeyParameters(
                rsa.Modulus, 
                rsa.PublicExponent, 
                rsa.PrivateExponent, 
                rsa.Prime1, 
                rsa.Prime2, 
                rsa.Exponent1, 
                rsa.Exponent2, 
                rsa.Coefficient);

            x509.PrivateKey = DotNetUtilities.ToRSA(rsaparams);

            File.WriteAllBytes(args.CertificateFileName.Replace(PfxExtension, CerExtension), x509.Export(System.Security.Cryptography.X509Certificates.X509ContentType.Cert));

            //// Export Certificate with private key
            File.WriteAllBytes(args.CertificateFileName, x509.Export(System.Security.Cryptography.X509Certificates.X509ContentType.Pkcs12, args.SelfSignedCertificatePrivateKeyFilePasswordSecureString));

            return x509;
        }

        public AsymmetricKeyParameter GenerateCertificateAuthorityCertificate(CertificateCreateArgs args, out System.Security.Cryptography.X509Certificates.X509Certificate2 outX509Cert, int keyStrength = KeyGenerationParametersKeyStrengthDefault)
        {
            //// Generating Random Numbers
            CryptoApiRandomGenerator randomGenerator = new CryptoApiRandomGenerator();
            SecureRandom random = new SecureRandom(randomGenerator);

            //// The Certificate Generator
            X509V3CertificateGenerator certificateGenerator = new X509V3CertificateGenerator();

            //// Serial Number
            BigInteger serialNumber = BigIntegers.CreateRandomInRange(BigInteger.One, BigInteger.ValueOf(long.MaxValue), random);
            certificateGenerator.SetSerialNumber(serialNumber);

            //// Signature Algorithm
            certificateGenerator.SetSignatureAlgorithm(SignatureAlgorithm);

            // Issuer and Subject Name
            X509Name subjectDN = new X509Name(args.MassagedCertificateAuthoritySubjectName);
            X509Name issuerDN = subjectDN;
            certificateGenerator.SetIssuerDN(issuerDN);
            certificateGenerator.SetSubjectDN(subjectDN);

            //// Valid For
            DateTime notBefore = DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0));
            DateTime notAfter = notBefore.AddYears(args.CertificateAddYears);
            certificateGenerator.SetNotBefore(notBefore);
            certificateGenerator.SetNotAfter(notAfter);

            KeyUsage keyUsage = new KeyUsage(KeyUsage.KeyCertSign | KeyUsage.CrlSign);
            certificateGenerator.AddExtension(X509Extensions.KeyUsage, true, keyUsage);

            //// Subject Public Key
            AsymmetricCipherKeyPair subjectKeyPair;
            KeyGenerationParameters keyGenerationParameters = new KeyGenerationParameters(random, keyStrength);
            RsaKeyPairGenerator keyPairGenerator = new RsaKeyPairGenerator();
            keyPairGenerator.Init(keyGenerationParameters);
            subjectKeyPair = keyPairGenerator.GenerateKeyPair();

            certificateGenerator.SetPublicKey(subjectKeyPair.Public);

            //// Generating the Certificate
            AsymmetricCipherKeyPair issuerKeyPair = subjectKeyPair;

            // selfsign certificate
            Org.BouncyCastle.X509.X509Certificate certificate = certificateGenerator.Generate(issuerKeyPair.Private, random);
            System.Security.Cryptography.X509Certificates.X509Certificate2 x509 = new System.Security.Cryptography.X509Certificates.X509Certificate2(certificate.GetEncoded());
            outX509Cert = x509;

            //// correcponding private key
            PrivateKeyInfo pinfo = PrivateKeyInfoFactory.CreatePrivateKeyInfo(subjectKeyPair.Private);

            Asn1Sequence seq = (Asn1Sequence)Asn1Object.FromByteArray(pinfo.PrivateKey.GetDerEncoded());
            if (seq.Count != Asn1SequenceCountNine)
            {
                throw new PemException("malformed sequence in RSA private key");
            }

            RsaPrivateKeyStructure rsa = new RsaPrivateKeyStructure(seq);
            RsaPrivateCrtKeyParameters rsaparams = new RsaPrivateCrtKeyParameters(
                rsa.Modulus, 
                rsa.PublicExponent, 
                rsa.PrivateExponent, 
                rsa.Prime1, 
                rsa.Prime2, 
                rsa.Exponent1, 
                rsa.Exponent2, 
                rsa.Coefficient);

            x509.PrivateKey = DotNetUtilities.ToRSA(rsaparams);

            if (args.AddCertificateAuthorityCertificateToStore)
            {
                // Add CA certificate to Root store
                this.AddCertToStore(x509, System.Security.Cryptography.X509Certificates.StoreName.Root, System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine);
            }

            File.WriteAllBytes(args.RootSigningCertificateFileName.Replace(PfxExtension, CerExtension), x509.Export(System.Security.Cryptography.X509Certificates.X509ContentType.Cert));

            //// Export Certificate with private key
            File.WriteAllBytes(args.RootSigningCertificateFileName, x509.Export(System.Security.Cryptography.X509Certificates.X509ContentType.Pkcs12, args.CertificateAuthorityPrivateKeyFilePasswordSecureString));

            return issuerKeyPair.Private;
        }

        public bool AddCertToStore(System.Security.Cryptography.X509Certificates.X509Certificate2 cert, System.Security.Cryptography.X509Certificates.StoreName st, System.Security.Cryptography.X509Certificates.StoreLocation sl)
        {
            bool bRet = false;

            try
            {
                System.Security.Cryptography.X509Certificates.X509Store store = new System.Security.Cryptography.X509Certificates.X509Store(st, sl);
                store.Open(System.Security.Cryptography.X509Certificates.OpenFlags.ReadWrite);
                store.Add(cert);

                store.Close();
            }
            catch
            {
                throw;
            }

            return bRet;
        }

        private CertificateCreateArgs MassageArgs(CertificateCreateArgs args)
        {
            if (string.IsNullOrEmpty(args.CertificateAuthoritySubjectName))
            {
                args.CertificateAuthoritySubjectName = Constants.DefaultValues.DefaultIssuer;
            }

            return args;
        }

        private void VerifyCertificateCreateArgs(CertificateCreateArgs args)
        {
            if (null == args)
            {
                throw new ArgumentNullException("CertificateCreateArgs was null");
            }

            if (string.IsNullOrEmpty(args.SelfSignedCertificateSubjectName))
            {
                throw new ArgumentNullException("CertificateCreateArgs.SelfSignedCertificateSubjectName was null or empty string");
            }

            if (args.CertificateAddYears < 1 || args.CertificateAddYears > 100)
            {
                throw new ArgumentOutOfRangeException("CertificateCreateArgs.CertificateAddYears must be postive and less than 100");
            }

            if (null == args.CertificateAuthorityPrivateKeyFilePasswordSecureString)
            {
                throw new ArgumentNullException("CertificateCreateArgs.CertificateAuthorityPrivateKeyFilePasswordSecureString was null");
            }

            if (null == args.SelfSignedCertificatePrivateKeyFilePasswordSecureString)
            {
                throw new ArgumentNullException("CertificateCreateArgs.SelfSignedCertificatePrivateKeyFilePasswordSecureString was null");
            }

            if (args.AddCertificateAuthorityCertificateToStore || args.AddSelfSignedCertificateToStore)
            {
                if (!AdministratorChecker.IsAdministrator())
                {
                    throw new ArgumentOutOfRangeException(string.Format("You must 'Run as Administrator' to add certficates to the stores. (AddCertificateAuthorityCertificateToStore={0}, AddSelfSignedCertificateToStore={1}", args.AddCertificateAuthorityCertificateToStore, args.AddSelfSignedCertificateToStore));
                }
            }
        }
    }
}