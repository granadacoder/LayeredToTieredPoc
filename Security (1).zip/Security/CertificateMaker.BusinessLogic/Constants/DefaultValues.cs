﻿//-----------------------------------------------------------------------
// <copyright file="DefaultValues.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Constants
{
    public static class DefaultValues
    {
        public const string DefaultIssuer = "BouncyCastleTrustedRootCertificateAuthority";
    }
}
