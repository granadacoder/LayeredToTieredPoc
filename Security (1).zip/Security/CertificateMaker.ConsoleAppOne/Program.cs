﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security;
using System.Text;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Args;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Constants;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Interfaces;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Utilities;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Utilities.Interfaces;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration;
using MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces;

using log4net;
using Microsoft.Practices.Unity;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.ConsoleAppOne
{
    public static class Program
    {
        public const int UnhandledExceptionErrorCode = 1;

        public const string EXITEARLY = "X";
        public const string CHOICEYES = "YES";
        public const string CHOICENO = "NO";

        public const string ConfigureChoiceManual = "M";
        public const string ConfigureChoicePredefined = "PD";

        private static readonly ILog TheLogger = LogManager.GetLogger(typeof(Program));

        public static int Main(string[] args)
        {
            int returnValue = 0;
            string logMsg = string.Empty;

            try
            {
                log4net.Config.XmlConfigurator.Configure();

                IUnityContainer container = new UnityContainer();

                container.RegisterType<ILog>(new InjectionFactory(x => LogManager.GetLogger(typeof(MyCoolCompany.Infrastructure.Security.CertificateMaker.ConsoleAppOne.Program))));

                container.RegisterType<ISelfSignedCertificateMaker, BouncyCastleSelfSignedCertificateMaker>();
                container.RegisterType<ICertificateReporter, StringBuilderCertificateReporter>();
                container.RegisterType<IAdministratorChecker, AdministratorChecker>();

                ISelfSignedCertificateMaker certMaker = container.Resolve<ISelfSignedCertificateMaker>();

                Console.Clear();

                string choice = string.Empty;

                string manualOrPredefinedChoiceSelection = string.Empty;
                SecureString certificateAuthorityPasswordSecureString = null;

                SecureString selfSignedCertificatePasswordSecureString = null;

                string selfSignedCertificateSubjectName = string.Empty;
                string certificateAuthoritySubjectName = string.Empty;

                List<string> subjectAlternateNames = new List<string>();
                int certificateAddYears = 0;
                bool addSelfSignedCertificateToStore = false;
                bool addCertificateAuthorityCertificateToStore = false;

                int selfSignedCertificateDefinitionUniqueIdentifierChoice = 0;

                bool goodChoice = false;

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine("Would you like to manually configure or use predefined?");
                    Console.WriteLine(string.Empty);
                    Console.WriteLine("{0} for manual", ConfigureChoiceManual);
                    Console.WriteLine("{0} for predefined", ConfigureChoicePredefined);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine("Type one of the above options (or {0} to exit) and ENTER key", EXITEARLY);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                    {
                        goodChoice = true;
                        return 0;
                    }

                    if (choice.Equals(ConfigureChoiceManual, StringComparison.OrdinalIgnoreCase))
                    {
                        goodChoice = true;
                        manualOrPredefinedChoiceSelection = choice;
                    }

                    if (choice.Equals(ConfigureChoicePredefined, StringComparison.OrdinalIgnoreCase))
                    {
                        goodChoice = true;
                        manualOrPredefinedChoiceSelection = choice;
                    }
                }

                CertificateCreateArgs certArgs = new CertificateCreateArgs();

                if (manualOrPredefinedChoiceSelection.Equals(ConfigureChoiceManual, StringComparison.OrdinalIgnoreCase))
                {
                    Console.Clear();

                    /*---------------*/
                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Please enter the subject name for the self signed certificate");
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Type a value (or {0} to exit) and ENTER key", EXITEARLY);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                        {
                            goodChoice = true;
                            return 0;
                        }

                        if (!string.IsNullOrEmpty(choice))
                        {
                            goodChoice = true;
                            selfSignedCertificateSubjectName = choice;
                        }
                    }

                    Console.Clear();

                    /*---------------*/
                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Please enter the subject name for the certificate authority certificate");
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("If you do not have a specific value, please use '{0}' (no quotes)", DefaultValues.DefaultIssuer);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Type a value (or {0} to exit) and ENTER key", EXITEARLY);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                        {
                            goodChoice = true;
                            return 0;
                        }

                        if (!string.IsNullOrEmpty(choice))
                        {
                            goodChoice = true;
                            certificateAuthoritySubjectName = choice;
                        }
                    }

                    Console.Clear();
                    selfSignedCertificatePasswordSecureString = GetVerifiedSecurePassword(string.Format("self signed certificate ('{0}')", selfSignedCertificateSubjectName));
                    Console.Clear();
                    certificateAuthorityPasswordSecureString = GetVerifiedSecurePassword(string.Format("certificate authority certificate ('{0}')", certificateAuthoritySubjectName));
                    Console.Clear();

                    /* start alternate names */
                    goodChoice = false;
                    while (!goodChoice)
                    {
                        ////* you can either add by wildcard */
                        //////subjectAlternateNames.Add("*.rd.mycoolcompany.com"); /* see https://www.digicert.com/subject-alternative-name.htm */

                        /////* or you can add by machine names on the farm */
                        ////subjectAlternateNames.Add("machine1.rd.mycoolcompany.com");
                        ////subjectAlternateNames.Add("machine1.rd.mycoolcompany.com");
                        ////subjectAlternateNames.Add("machine1.rd.mycoolcompany.com");

                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Please enter any/all Subject Alternate Name(s) for the self signed certificate");
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Type a value.  When done, enter an empty string (or {0} to exit) and ENTER key", EXITEARLY);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                        {
                            goodChoice = true;
                            return 0;
                        }

                        if (!string.IsNullOrEmpty(choice))
                        {
                            subjectAlternateNames.Add(choice);
                        }
                        else
                        {
                            goodChoice = true;
                        }

                        Console.WriteLine(string.Empty);
                        Console.WriteLine(string.Empty);
                    }

                    Console.Clear();

                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Please enter the number of YEARS for the certificate to expire");
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Type a number (or {0} to exit) and ENTER key", EXITEARLY);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                        {
                            goodChoice = true;
                            return 0;
                        }

                        bool tryParseResult = int.TryParse(choice, out certificateAddYears);
                        if (tryParseResult)
                        {
                            goodChoice = true;
                        }
                    }

                    Console.Clear();

                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.Clear();
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Do you want to write the certificate authority certificate to {0} {1}", "System.Security.Cryptography.X509Certificates.StoreName.Root", "System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine");
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Type {0} or {1} (case sensitive) (or {2} to exit) and ENTER key", CHOICEYES, CHOICENO, EXITEARLY);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                        {
                            goodChoice = true;
                            return 0;
                        }

                        if (choice.Equals(CHOICEYES))
                        {
                            goodChoice = true;
                            addCertificateAuthorityCertificateToStore = true;
                        }

                        if (choice.Equals(CHOICENO))
                        {
                            goodChoice = true;
                        }
                    }

                    Console.Clear();

                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.Clear();
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Do you want to write the self signed certificate to {0} {1}", "System.Security.Cryptography.X509Certificates.StoreName.My", "System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine");
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Type {0} or {1} (case sensitive) (or {2} to exit) and ENTER key", CHOICEYES, CHOICENO, EXITEARLY);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                        {
                            goodChoice = true;
                            return 0;
                        }

                        if (choice.Equals(CHOICEYES))
                        {
                            goodChoice = true;
                            addSelfSignedCertificateToStore = true;
                        }

                        if (choice.Equals(CHOICENO))
                        {
                            goodChoice = true;
                        }
                    }

                    certArgs.SelfSignedCertificateSubjectName = selfSignedCertificateSubjectName;
                    certArgs.CertificateAuthoritySubjectName = certificateAuthoritySubjectName;
                    certArgs.SubjectAlternateNames = subjectAlternateNames;
                    certArgs.CertificateAuthorityPrivateKeyFilePasswordSecureString = certificateAuthorityPasswordSecureString;
                    certArgs.SelfSignedCertificatePrivateKeyFilePasswordSecureString = selfSignedCertificatePasswordSecureString;
                    certArgs.CertificateAddYears = certificateAddYears;
                    certArgs.AddCertificateAuthorityCertificateToStore = addCertificateAuthorityCertificateToStore;
                    certArgs.AddSelfSignedCertificateToStore = addSelfSignedCertificateToStore;

                    certArgs = MassageCertArg(certArgs);
                }

                if (manualOrPredefinedChoiceSelection.Equals(ConfigureChoicePredefined, StringComparison.OrdinalIgnoreCase))
                {
                    Console.Clear();
                    ISelfSignedCertificateDefinitionConfigurationSection section = new SelfSignedCertificateDefinitionConfigurationRetriever().GetISelfSignedCertificateDefinitionConfigurationSection();
                    foreach (SelfSignedCertificateDefinitionConfigurationElement sec in section.ISelfSignedCertificateDefinitions)
                    {
                        Console.WriteLine("Id='{0}', {1}, {2}, FriendlyName={3}", sec.SelfSignedCertificateDefinitionUniqueIdentifier, sec.SelfSignedCertificateSubjectName, sec.CertificateAuthoritySubjectName, sec.SelfSignedCertificateFriendlyName);
                        foreach (SubjectAlternateNameConfigurationElement san in sec.SubjectAlternateNames)
                        {
                            Console.WriteLine("    --SubjectAlternateNameValue='{0}'", san.SubjectAlternateNameValue);
                        }

                        Console.WriteLine(string.Empty);
                    }

                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Pick a predefined using the value for the 'Id'");
                        Console.WriteLine(string.Empty);
                        Console.WriteLine("Type one of the above numbers (or {0} to exit) and ENTER key", EXITEARLY);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                        {
                            goodChoice = true;
                            return 0;
                        }

                        bool tryParseResult = int.TryParse(choice, out selfSignedCertificateDefinitionUniqueIdentifierChoice);

                        if (tryParseResult)
                        {
                            ISelfSignedCertificateDefinitionFinder finder = new SelfSignedCertificateDefinitionFinder();
                            SelfSignedCertificateDefinitionConfigurationElement foundDef = finder.FindSelfSignedCertificateDefinitionConfigurationElementByUniqueId(selfSignedCertificateDefinitionUniqueIdentifierChoice);
                            if (null != foundDef)
                            {
                                certArgs.SelfSignedCertificateSubjectName = foundDef.SelfSignedCertificateSubjectName;
                                certArgs.CertificateAuthoritySubjectName = foundDef.CertificateAuthoritySubjectName;
                                certArgs.CertificateAddYears = foundDef.CertificateAddYears;
                                certArgs.AddCertificateAuthorityCertificateToStore = foundDef.AddCertificateAuthorityCertificateToStore;
                                certArgs.AddSelfSignedCertificateToStore = foundDef.AddSelfSignedCertificateToStore;
                                foreach (SubjectAlternateNameConfigurationElement san in foundDef.SubjectAlternateNames)
                                {
                                    certArgs.SubjectAlternateNames.Add(san.SubjectAlternateNameValue);
                                }

                                Console.Clear();
                                selfSignedCertificatePasswordSecureString = GetVerifiedSecurePassword(string.Format("self signed certificate ('{0}')", certArgs.SelfSignedCertificateSubjectName));
                                Console.Clear();
                                certificateAuthorityPasswordSecureString = GetVerifiedSecurePassword(string.Format("certificate authority certificate ('{0}')", certArgs.CertificateAuthoritySubjectName));
                                Console.Clear();

                                certArgs.CertificateAuthorityPrivateKeyFilePasswordSecureString = certificateAuthorityPasswordSecureString;
                                certArgs.SelfSignedCertificatePrivateKeyFilePasswordSecureString = selfSignedCertificatePasswordSecureString;

                                certArgs = MassageCertArg(certArgs);

                                goodChoice = true;
                            }
                        }
                    }
                }

                Console.Clear();
                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine("SelfSignedCertificateSubjectName='{0}'", certArgs.SelfSignedCertificateSubjectName);
                    Console.WriteLine("CertificateAuthoritySubjectName='{0}'", certArgs.CertificateAuthoritySubjectName);
                    int sanCounter = 0;
                    foreach (string san in certArgs.SubjectAlternateNames)
                    {
                        Console.WriteLine("SubjectAlternateNames[{0}]='{1}'", ++sanCounter, san);
                    }

                    Console.WriteLine("CertificateAddYears='{0}'", certArgs.CertificateAddYears);
                    Console.WriteLine("AddCertificateAuthorityCertificateToStore='{0}'", certArgs.AddCertificateAuthorityCertificateToStore);
                    Console.WriteLine("AddSelfSignedCertificateToStore='{0}'", certArgs.AddSelfSignedCertificateToStore);

                    Console.WriteLine(string.Empty);
                    Console.WriteLine("Please type {0} to continue with the above options/choices", CHOICEYES);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine("Or type {0} to exit and ENTER key", EXITEARLY);
                    Console.WriteLine(string.Empty);

                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(EXITEARLY, StringComparison.OrdinalIgnoreCase))
                    {
                        goodChoice = true;
                        return 0;
                    }

                    if (choice.Equals(CHOICEYES, StringComparison.OrdinalIgnoreCase))
                    {
                        goodChoice = true;
                    }
                }

                string rootFolder = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N"));
                string certFileName = Path.Combine(rootFolder, certArgs.SelfSignedCertificateSubjectName + ".pfx");
                string rootsigningCertFileName = Path.Combine(rootFolder, certArgs.CertificateAuthoritySubjectName + ".pfx");

                certArgs.CertificateFileName = certFileName;
                certArgs.RootSigningCertificateFileName = rootsigningCertFileName;

                if (!Directory.Exists(rootFolder))
                {
                    Directory.CreateDirectory(rootFolder);
                }

                certMaker.CreateSelfSignedCertificate(certArgs);

                Console.WriteLine("Files written to : '{0}'", rootFolder);

                Process.Start("explorer.exe", rootFolder);
            }
            catch (System.Security.Cryptography.CryptographicException ces)
            {
                Console.WriteLine("Because this code writes to the certificate store to the computer, you must run VS 'As Administrator' to run this console app");
                Console.WriteLine(GenerateFullFlatMessage(ces, true));
            }
            catch (Exception e)
            {
                TheLogger.Error(e.Message, e);
                Console.WriteLine("Unexpected Exception : {0}", GenerateFullFlatMessage(e));
                returnValue = UnhandledExceptionErrorCode;
            }

            Console.WriteLine("END : {0}", System.Diagnostics.Process.GetCurrentProcess().ProcessName);
            Console.WriteLine(string.Empty);

            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();

            return returnValue;
        }

        private static SecureString GetVerifiedSecurePassword(string passwordTagName)
        {
            bool goodChoice;

            SecureString passwordSecureString = null;
            SecureString passwordSecureStringVerify = null;

            goodChoice = false;
            while (!goodChoice)
            {
                while (!goodChoice)
                {
                    Console.WriteLine("Please enter password for the {0}", passwordTagName);
                    passwordSecureString = GetSecurePassword();
                    if (null != passwordSecureString)
                    {
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine("Please enter password validation for the {0}", passwordTagName);
                    passwordSecureStringVerify = GetSecurePassword();
                    if (null != passwordSecureStringVerify)
                    {
                        goodChoice = true;
                    }
                }

                if (!SecureStringComparer.IsEqualTo(passwordSecureString, passwordSecureStringVerify))
                {
                    Console.Clear();
                    Console.WriteLine("Certificate authority passwords not same.  Please try again.");
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    goodChoice = false;
                }
            }

            return passwordSecureString;
        }

        private static CertificateCreateArgs MassageCertArg(CertificateCreateArgs certArgs)
        {
            string rootFolder = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N"));
            string certFileName = Path.Combine(rootFolder, certArgs.SelfSignedCertificateSubjectName + ".pfx");
            string rootsigningCertFileName = Path.Combine(rootFolder, certArgs.CertificateAuthoritySubjectName + ".pfx");

            if (!Directory.Exists(rootFolder))
            {
                Directory.CreateDirectory(rootFolder);
            }

            if (System.IO.File.Exists(certFileName))
            {
                System.IO.File.Delete(certFileName);
            }

            if (System.IO.File.Exists(rootsigningCertFileName))
            {
                System.IO.File.Delete(rootsigningCertFileName);
            }

            certArgs.CertificateFileName = certFileName;
            certArgs.RootSigningCertificateFileName = rootsigningCertFileName;

            return certArgs;
        }

        private static SecureString GetSecurePassword()
        {
            var pwd = new SecureString();
            while (true)
            {
                ConsoleKeyInfo i = Console.ReadKey(true);
                if (i.Key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (i.Key == ConsoleKey.Backspace)
                {
                    if (pwd.Length > 0)
                    {
                        pwd.RemoveAt(pwd.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else
                {
                    pwd.AppendChar(i.KeyChar);
                    Console.Write("*");
                }
            }

            pwd.MakeReadOnly();

            return pwd;
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
