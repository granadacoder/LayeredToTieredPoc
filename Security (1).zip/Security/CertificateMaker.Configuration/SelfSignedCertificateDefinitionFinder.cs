﻿//-----------------------------------------------------------------------
// <copyright file="SelfSignedCertificateDefinitionFinder.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    public class SelfSignedCertificateDefinitionFinder : ISelfSignedCertificateDefinitionFinder
    {
        private const string ErrorMessageMoreThanOneMatch = "More than item was found with the selection criteria. ({0})";

        private const string ErrorMessageNoMatch = "No item was found with the selection criteria. ({0})";

        public SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElement(ISelfSignedCertificateDefinitionConfigurationSection settings, string selfSignedCertificateSubjectName)
        {
            SelfSignedCertificateDefinitionConfigurationElement returnItem = null;

            if (null != settings && null != settings.ISelfSignedCertificateDefinitions)
            {
                ICollection<SelfSignedCertificateDefinitionConfigurationElement> matchingFarmItems;
                matchingFarmItems = settings.ISelfSignedCertificateDefinitions.Where(ele => selfSignedCertificateSubjectName.Equals(ele.SelfSignedCertificateSubjectName, StringComparison.OrdinalIgnoreCase)).ToList();

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingFarmItems.FirstOrDefault();
            }

            return returnItem;
        }

        public SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElement(string selfSignedCertificateSubjectName)
        {
            ISelfSignedCertificateDefinitionConfigurationSection settings = new SelfSignedCertificateDefinitionConfigurationRetriever().GetISelfSignedCertificateDefinitionConfigurationSection();
            return this.FindSelfSignedCertificateDefinitionConfigurationElement(settings, selfSignedCertificateSubjectName);
        }

        public SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElementByUniqueId(int id)
        {
            ISelfSignedCertificateDefinitionConfigurationSection settings = new SelfSignedCertificateDefinitionConfigurationRetriever().GetISelfSignedCertificateDefinitionConfigurationSection();
            return this.FindSelfSignedCertificateDefinitionConfigurationElementByUniqueId(settings, id);
        }

        public SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElementByUniqueId(ISelfSignedCertificateDefinitionConfigurationSection settings, int id)
        {
            SelfSignedCertificateDefinitionConfigurationElement returnItem = null;

            if (null != settings && null != settings.ISelfSignedCertificateDefinitions)
            {
                ICollection<SelfSignedCertificateDefinitionConfigurationElement> matchingFarmItems;
                matchingFarmItems = settings.ISelfSignedCertificateDefinitions.Where(ele => id == ele.SelfSignedCertificateDefinitionUniqueIdentifier).ToList();

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingFarmItems.FirstOrDefault();
            }

            return returnItem;
        }

        private string BuildErrorDetails(ICollection<SelfSignedCertificateDefinitionConfigurationElement> items)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();

            if (null != items)
            {
                foreach (SelfSignedCertificateDefinitionConfigurationElement item in items)
                {
                    sb.Append(string.Format("SelfSignedCertificateSubjectName='{0}'.", item.SelfSignedCertificateSubjectName));
                }
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
