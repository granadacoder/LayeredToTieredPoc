//-----------------------------------------------------------------------
// <copyright file="SelfSignedCertificateDefinitionConfigurationElement.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Configuration;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    [System.Diagnostics.DebuggerDisplay("SelfSignedCertificateSubjectName = '{SelfSignedCertificateSubjectName}'")]
    public class SelfSignedCertificateDefinitionConfigurationElement : ConfigurationElement
    {
        private const string SelfSignedCertificateSubjectNamePropertyName = "selfSignedCertificateSubjectName";
        private const string CertificateAuthoritySubjectNamePropertyName = "certificateAuthoritySubjectName";
        private const string CertificateAddYearsPropertyName = "certificateAddYears";
        private const string SelfSignedCertificateDefinitionUniqueIdentifierPropertyName = "selfSignedCertificateDefinitionUniqueIdentifier";
        private const string AddCertificateAuthorityCertificateToStorePropertyName = "addCertificateAuthorityCertificateToStore";
        private const string AddSelfSignedCertificateToStorePropertyName = "addSelfSignedCertificateToStore";
        private const string SelfSignedCertificateFriendlyNamePropertyName = "selfSignedCertificateFriendlyName";

        private const string SubjectAlternateNamesPropertyName = "subjectAlternateNames";
        private const string ServiceBusQueuesPropertyName = "serviceBusQueues";

        [ConfigurationProperty(SelfSignedCertificateSubjectNamePropertyName, IsRequired = true, IsKey = true)]
        [StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string SelfSignedCertificateSubjectName
        {
            get { return (string)this[SelfSignedCertificateSubjectNamePropertyName]; }
            set { this[SelfSignedCertificateSubjectNamePropertyName] = value; }
        }

        [ConfigurationProperty(CertificateAuthoritySubjectNamePropertyName, IsRequired = true, IsKey = true)]
        [StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string CertificateAuthoritySubjectName
        {
            get { return (string)this[CertificateAuthoritySubjectNamePropertyName]; }
            set { this[CertificateAuthoritySubjectNamePropertyName] = value; }
        }

        [ConfigurationProperty(CertificateAddYearsPropertyName, IsRequired = true)]
        public int CertificateAddYears
        {
            get { return (int)this[CertificateAddYearsPropertyName]; }
            set { this[CertificateAddYearsPropertyName] = value; }
        }

        [ConfigurationProperty(SelfSignedCertificateDefinitionUniqueIdentifierPropertyName, IsRequired = true)]
        public int SelfSignedCertificateDefinitionUniqueIdentifier
        {
            get { return (int)this[SelfSignedCertificateDefinitionUniqueIdentifierPropertyName]; }
            set { this[SelfSignedCertificateDefinitionUniqueIdentifierPropertyName] = value; }
        }

        [ConfigurationProperty(AddCertificateAuthorityCertificateToStorePropertyName, IsRequired = true)]
        public bool AddCertificateAuthorityCertificateToStore
        {
            get { return (bool)this[AddCertificateAuthorityCertificateToStorePropertyName]; }
            set { this[AddCertificateAuthorityCertificateToStorePropertyName] = value; }
        }
        
        [ConfigurationProperty(AddSelfSignedCertificateToStorePropertyName, IsRequired = true)]
        public bool AddSelfSignedCertificateToStore
        {
            get { return (bool)this[AddSelfSignedCertificateToStorePropertyName]; }
            set { this[AddSelfSignedCertificateToStorePropertyName] = value; }
        }

        [ConfigurationProperty(SubjectAlternateNamesPropertyName, IsDefaultCollection = false)]
        public SubjectAlternateNameCollection SubjectAlternateNames
        {
            get { return (SubjectAlternateNameCollection)base[SubjectAlternateNamesPropertyName]; }
            set { this[SubjectAlternateNamesPropertyName] = value; } /* set is here for UnitTests */
        }

        [ConfigurationProperty(SelfSignedCertificateFriendlyNamePropertyName, IsRequired = true, IsKey = true)]
        public string SelfSignedCertificateFriendlyName
        {
            get { return (string)this[SelfSignedCertificateFriendlyNamePropertyName]; }
            set { this[SelfSignedCertificateFriendlyNamePropertyName] = value; }
        }
    }
}
