//-----------------------------------------------------------------------
// <copyright file="SelfSignedCertificateDefinitionConfigurationSection.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Configuration;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    public class SelfSignedCertificateDefinitionConfigurationSection : ConfigurationSection, ISelfSignedCertificateDefinitionConfigurationSection
    {
        [ConfigurationProperty("", IsDefaultCollection = true)]
        public SelfSignedCertificateDefinitionCollection SelfSignedCertificateDefinitions
        {
            get
            {
                SelfSignedCertificateDefinitionCollection coll = (SelfSignedCertificateDefinitionCollection)base[string.Empty];
                return coll;
            }
        }

        /* Here is the interface property that simply returns the non-interface property from above.  This allows System.Configuration to hydrate the non-interface property, but allows the code to be written (and unit test mocks to be written) against the interface property. */
        public ISelfSignedCertificateDefinitionCollection ISelfSignedCertificateDefinitions
        {
            get { return this.SelfSignedCertificateDefinitions; }
        }
    }
}
