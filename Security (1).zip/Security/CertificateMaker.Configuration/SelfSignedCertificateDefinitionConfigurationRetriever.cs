//-----------------------------------------------------------------------
// <copyright file="SelfSignedCertificateDefinitionConfigurationRetriever.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Configuration;
using System.Linq;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    public class SelfSignedCertificateDefinitionConfigurationRetriever : ISelfSignedCertificateDefinitionConfigurationSectionRetriever
    {
        public static readonly string ConfigurationSectionName = "SelfSignedCertificateDefinitionConfigurationSectionName";

        public ISelfSignedCertificateDefinitionConfigurationSection GetISelfSignedCertificateDefinitionConfigurationSection()
        {
            SelfSignedCertificateDefinitionConfigurationSection returnSection = (SelfSignedCertificateDefinitionConfigurationSection)ConfigurationManager.GetSection(ConfigurationSectionName);
            if (returnSection != null)
            {
                var duplicates = returnSection.ISelfSignedCertificateDefinitions.GroupBy(i => new { i.SelfSignedCertificateDefinitionUniqueIdentifier })
                  .Where(g => g.Count() > 1)
                  .Select(g => g.Key);

                if (duplicates.Count() > 1)
                {
                    throw new ArgumentOutOfRangeException("Duplicate SelfSignedCertificateDefinitionUniqueIdentifier values.", Convert.ToString(duplicates.First().SelfSignedCertificateDefinitionUniqueIdentifier));
                }

                return returnSection;
            }

            return null;
        }
    }
}