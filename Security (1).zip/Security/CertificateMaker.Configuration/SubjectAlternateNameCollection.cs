//-----------------------------------------------------------------------
// <copyright file="SubjectAlternateNameCollection.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using System.Configuration;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    [ConfigurationCollection(typeof(SubjectAlternateNameConfigurationElement))]
    public class SubjectAlternateNameCollection : ConfigurationElementCollection, IEnumerable<SubjectAlternateNameConfigurationElement>
    {
        public override ConfigurationElementCollectionType CollectionType
        {
            get { return ConfigurationElementCollectionType.BasicMap; }
        }

        protected override string ElementName
        {
            get { return "subjectAlternateName"; }
        }

        public SubjectAlternateNameConfigurationElement this[int index]
        {
            get { return (SubjectAlternateNameConfigurationElement)BaseGet(index); }
        }

        public new SubjectAlternateNameConfigurationElement this[string name]
        {
            get
            {
                if (this.IndexOf(name) < 0)
                {
                    return null;
                }

                return (SubjectAlternateNameConfigurationElement)BaseGet(name);
            }
        }

        public void Add(SubjectAlternateNameConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public int IndexOf(string subjectAlternateNameValue)
        {
            for (int idx = 0; idx < this.Count; idx++)
            {
                if (this[idx].SubjectAlternateNameValue.ToLower(System.Globalization.CultureInfo.CurrentCulture) == subjectAlternateNameValue.ToLower(System.Globalization.CultureInfo.CurrentCulture))
                {
                    return idx;
                }
            }

            return -1;
        }

        public new IEnumerator<SubjectAlternateNameConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as SubjectAlternateNameConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new SubjectAlternateNameConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((SubjectAlternateNameConfigurationElement)element).SubjectAlternateNameValue;
        }
    }
}
