﻿//-----------------------------------------------------------------------
// <copyright file="ISelfSignedCertificateDefinitionConfigurationSection.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces
{
    public interface ISelfSignedCertificateDefinitionConfigurationSection
    {
        ISelfSignedCertificateDefinitionCollection ISelfSignedCertificateDefinitions { get; }
    }
}