﻿//-----------------------------------------------------------------------
// <copyright file="ISelfSignedCertificateDefinitionConfigurationSectionRetriever.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces
{
    public interface ISelfSignedCertificateDefinitionConfigurationSectionRetriever
    {
        ISelfSignedCertificateDefinitionConfigurationSection GetISelfSignedCertificateDefinitionConfigurationSection();
    }
}
