﻿//-----------------------------------------------------------------------
// <copyright file="ISelfSignedCertificateDefinitionCollection.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces
{
    public interface ISelfSignedCertificateDefinitionCollection : IList<SelfSignedCertificateDefinitionConfigurationElement>, IEnumerable<SelfSignedCertificateDefinitionConfigurationElement> /* Implement IEnumerable to allow Linq queries */
    {
        SelfSignedCertificateDefinitionConfigurationElement this[string name] { get; }

        void Remove(string name);
    }
}
