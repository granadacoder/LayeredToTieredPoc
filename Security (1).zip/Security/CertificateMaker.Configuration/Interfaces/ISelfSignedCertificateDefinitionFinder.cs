﻿//-----------------------------------------------------------------------
// <copyright file="ISelfSignedCertificateDefinitionFinder.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces
{
    public interface ISelfSignedCertificateDefinitionFinder
    {
        SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElement(ISelfSignedCertificateDefinitionConfigurationSection settings, string selfSignedCertificateSubjectName);

        SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElement(string selfSignedCertificateSubjectName);

        SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElementByUniqueId(int id);

        SelfSignedCertificateDefinitionConfigurationElement FindSelfSignedCertificateDefinitionConfigurationElementByUniqueId(ISelfSignedCertificateDefinitionConfigurationSection settings, int id);
  }
}
