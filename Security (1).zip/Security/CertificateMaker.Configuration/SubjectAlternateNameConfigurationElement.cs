//-----------------------------------------------------------------------
// <copyright file="SubjectAlternateNameConfigurationElement.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.ComponentModel;
using System.Configuration;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    [System.Diagnostics.DebuggerDisplay("SubjectAlternateNameValue='{SubjectAlternateNameValue}'")]
    public class SubjectAlternateNameConfigurationElement : ConfigurationElement
    {
        private const string SubjectAlternateNameValuePropertyName = "subjectAlternateNameValue";

        public SubjectAlternateNameConfigurationElement()
        {
        }

        public SubjectAlternateNameConfigurationElement(string subjectAlternateNameValue)
        {
            this.SubjectAlternateNameValue = subjectAlternateNameValue;
        }

        [ConfigurationProperty(SubjectAlternateNameValuePropertyName, IsRequired = true, IsKey = true, DefaultValue = "")]
        [StringValidator(InvalidCharacters = "  ~!@#$%^&()[]{}/;’\"|\\")] /* note, the '*' was removed */
        public string SubjectAlternateNameValue
        {
            get { return (string)this[SubjectAlternateNameValuePropertyName]; }
            set { this[SubjectAlternateNameValuePropertyName] = value; }
        }
    }
}