﻿//-----------------------------------------------------------------------
// <copyright file="SubjectAlternateNameMatchEnum.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    public enum SubjectAlternateNameMatchEnum
    {
        CaseInsensitive
    }
}