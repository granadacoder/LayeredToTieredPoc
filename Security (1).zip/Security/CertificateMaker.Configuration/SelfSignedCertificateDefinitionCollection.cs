//-----------------------------------------------------------------------
// <copyright file="SelfSignedCertificateDefinitionCollection.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration.Interfaces;

namespace MyCoolCompany.Infrastructure.Security.CertificateMaker.Configuration
{
    [ConfigurationCollection(typeof(SelfSignedCertificateDefinitionConfigurationElement))]
    public class SelfSignedCertificateDefinitionCollection : ConfigurationElementCollection, ISelfSignedCertificateDefinitionCollection
    {
        public SelfSignedCertificateDefinitionCollection()
        {
            SelfSignedCertificateDefinitionConfigurationElement details = (SelfSignedCertificateDefinitionConfigurationElement)this.CreateNewElement();
            if (!string.IsNullOrEmpty(details.SelfSignedCertificateSubjectName))
            {
                this.Add(details);
            }
        }

        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.BasicMap;
            }
        }

        bool ICollection<SelfSignedCertificateDefinitionConfigurationElement>.IsReadOnly
        {
            get
            {
                return false;
            }
        }

        protected override string ElementName
        {
            get { return "selfSignedCertificateDefinition"; }
        }

        public SelfSignedCertificateDefinitionConfigurationElement this[int index]
        {
            get
            {
                return (SelfSignedCertificateDefinitionConfigurationElement)BaseGet(index);
            }

            set
            {
                if (this.BaseGet(index) != null)
                {
                    this.BaseRemoveAt(index);
                }

                this.BaseAdd(index, value);
            }
        }

        public new SelfSignedCertificateDefinitionConfigurationElement this[string name]
        {
            get
            {
                return (SelfSignedCertificateDefinitionConfigurationElement)this.BaseGet(name);
            }
        }

        public int IndexOf(SelfSignedCertificateDefinitionConfigurationElement details)
        {
            return this.BaseIndexOf(details);
        }

        public void Add(SelfSignedCertificateDefinitionConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public bool Remove(SelfSignedCertificateDefinitionConfigurationElement details)
        {
            if (this.BaseIndexOf(details) >= 0)
            {
                this.BaseRemove(details.SelfSignedCertificateSubjectName);
                return true;
            }

            return false;
        }

        public void RemoveAt(int index)
        {
            this.BaseRemoveAt(index);
        }

        public void Remove(string name)
        {
            this.BaseRemove(name);
        }

        public void Clear()
        {
            this.BaseClear();
        }

        public bool Contains(SelfSignedCertificateDefinitionConfigurationElement item)
        {
            if (this.IndexOf(item) >= 0)
            {
                return true;
            }

            return false;
        }

        public void CopyTo(SelfSignedCertificateDefinitionConfigurationElement[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index, SelfSignedCertificateDefinitionConfigurationElement item)
        {
            this.BaseAdd(index, item);
        }

        public new IEnumerator<SelfSignedCertificateDefinitionConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as SelfSignedCertificateDefinitionConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new SelfSignedCertificateDefinitionConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((SelfSignedCertificateDefinitionConfigurationElement)element).SelfSignedCertificateSubjectName;
        }

        protected override void BaseAdd(ConfigurationElement element)
        {
            this.BaseAdd(element, false);
        }
    }
}