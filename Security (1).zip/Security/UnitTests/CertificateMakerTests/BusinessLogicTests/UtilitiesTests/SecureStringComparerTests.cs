﻿//-----------------------------------------------------------------------
// <copyright file="SecureStringComparerTests.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCoolCompany.Infrastructure.Security.UnitTests.CertificateMakerTests.BusinessLogicTests.UtilitiesTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SecureStringComparerTests
    {
        [TestMethod]
        public void IsEqualToTrueTest()
        {
            string randomChars = Guid.NewGuid().ToString("N");
            SecureString ssOne = new SecureString();
            SecureString ssTwo = new SecureString();
            foreach (char c in randomChars)
            {
                ssOne.AppendChar(c);
                ssTwo.AppendChar(c);
            }

            Assert.IsTrue(SecureStringComparer.IsEqualTo(ssOne, ssTwo));
        }

        [TestMethod]
        public void IsEqualToFalseTest()
        {
            string randomChars1 = Guid.NewGuid().ToString("N");
            string randomChars2 = Guid.NewGuid().ToString("N");
            SecureString ssOne = new SecureString();
            SecureString ssTwo = new SecureString();
            foreach (char c in randomChars1)
            {
                ssOne.AppendChar(c);
            }

            foreach (char c in randomChars2)
            {
                ssTwo.AppendChar(c);
            }

            Assert.IsFalse(SecureStringComparer.IsEqualTo(ssOne, ssTwo));
        }
    }
}