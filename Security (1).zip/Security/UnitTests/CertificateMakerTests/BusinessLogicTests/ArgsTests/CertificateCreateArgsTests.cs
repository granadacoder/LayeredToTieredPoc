﻿//-----------------------------------------------------------------------
// <copyright file="CertificateCreateArgsTests.cs" company="MyCoolCompany">
//     Copyright (c) MyCoolCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using MyCoolCompany.Infrastructure.Security.CertificateMaker.BusinessLogic.Args;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCoolCompany.Infrastructure.Security.UnitTests.CertificateMakerTests.BusinessLogicTests.ArgsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CertificateCreateArgsTests
    {
        [TestMethod]
        public void CertificateCreateArgsScalarTest()
        {
            const string SelfSignedCertificateSubjectNameOne = "SelfSignedCertificateSubjectNameOne";
            ICollection<string> sans = new List<string> { "sans1", "san2", "sans3" };
            const string CertificateFileNameOne = "CertificateFileNameOne";
            const string CertificateAuthoritySubjectNameOne = "CertificateAuthoritySubjectNameOne";
            SecureString secureStringOne = new SecureString();
            SecureString secureStringTwo = new SecureString();
            const string RootSigningCertificateFileNameOne = "RootSigningCertificateFileNameOne";
            const int CertificateAddYearsOne = 1;
            const bool AddCertificateAuthorityCertificateToStoreOne = true;
            const bool AddSelfSignedCertificateToStoreOne = true;

            CertificateCreateArgs args = new CertificateCreateArgs();
            Assert.IsNotNull(args.SubjectAlternateNames);
            args.SelfSignedCertificateSubjectName = SelfSignedCertificateSubjectNameOne;
            args.SubjectAlternateNames = sans;
            args.CertificateFileName = CertificateFileNameOne;
            args.CertificateAuthoritySubjectName = CertificateAuthoritySubjectNameOne;
            args.CertificateAuthorityPrivateKeyFilePasswordSecureString = secureStringOne;
            args.SelfSignedCertificatePrivateKeyFilePasswordSecureString = secureStringTwo;
            args.RootSigningCertificateFileName = RootSigningCertificateFileNameOne;
            args.CertificateAddYears = CertificateAddYearsOne;
            args.AddCertificateAuthorityCertificateToStore = AddCertificateAuthorityCertificateToStoreOne;
            args.AddSelfSignedCertificateToStore = AddSelfSignedCertificateToStoreOne;

            Assert.IsNotNull(args);
            Assert.AreEqual(SelfSignedCertificateSubjectNameOne, args.SelfSignedCertificateSubjectName);
            Assert.AreEqual(string.Format(CertificateCreateArgs.CertificateMassageName, args.SelfSignedCertificateSubjectName), args.MassagedSelfSignedCertificateSubjectName);
            Assert.AreEqual(sans, args.SubjectAlternateNames);
            Assert.AreEqual(CertificateFileNameOne, args.CertificateFileName);
            Assert.AreEqual(CertificateAuthoritySubjectNameOne, args.CertificateAuthoritySubjectName);
            Assert.AreEqual(string.Format(CertificateCreateArgs.CertificateMassageName, args.CertificateAuthoritySubjectName), args.MassagedCertificateAuthoritySubjectName);
            Assert.AreEqual(secureStringOne, args.CertificateAuthorityPrivateKeyFilePasswordSecureString);
            Assert.AreEqual(secureStringTwo, args.SelfSignedCertificatePrivateKeyFilePasswordSecureString);
            Assert.AreEqual(RootSigningCertificateFileNameOne, args.RootSigningCertificateFileName);
            Assert.AreEqual(CertificateAddYearsOne, args.CertificateAddYears);
            Assert.AreEqual(AddCertificateAuthorityCertificateToStoreOne, args.AddCertificateAuthorityCertificateToStore);
            Assert.AreEqual(AddSelfSignedCertificateToStoreOne, args.AddSelfSignedCertificateToStore);
        }
    }
}
